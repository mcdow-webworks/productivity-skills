# Notes - [Month Year]

<!-- 
This is your monthly notes file. Entries are automatically added below.
You can also add entries manually - just follow the format.

Format:
# Category - Brief description
Details about the entry...

Common categories:
- Idea: New concepts or features
- Meeting: Discussion notes
- Update: Status changes
- Question: Things to explore
- Decision: Conclusions reached
- Work: Daily accomplishments
- Learning: Insights from reading/research
-->

